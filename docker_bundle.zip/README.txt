# Быстрый старт

1) Убедитесь, что в .env заполнены переменные:
   - BOT_TOKEN
   - DATABASE_URL
   - ADMIN_USERNAMES

2) Запуск:
   docker compose up -d --build

3) Логи:
   docker compose logs -f

Файлы в архиве:
- .env
- Dockerfile
- docker-compose.yml
- requirements.txt
